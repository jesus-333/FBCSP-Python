Due to a transmission error, the 1000Hz version of the evaluation data
set of subject 'a' did contain only the first 1759140 sample
points. This error was fixed during the competition, but some
competitors did already download the cropped version. Therefore only
the first 1759140 sample points of data set 1a have been considered
for evaluation.
